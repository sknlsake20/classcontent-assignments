package com.src.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.src.dao.MedDAO;
import com.src.model.Medicine;

public class MainApplication {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		MedDAO dao=(MedDAO) context.getBean("meddao");
		int status=dao.updateMedicine(new Medicine(1001,"Paracetamol","Apex",5,"12/12/2020", "12/11/2022"));
		if(status>0)
		{
			System.out.println("Inserted sucessfully");
		}
		
		else
		{
			System.out.println("unsucessfull insertion");
		}

	}

}