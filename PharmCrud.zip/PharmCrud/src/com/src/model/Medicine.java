package com.src.model;

public class Medicine {
	private int medid;
	private String medname;
	private String manufacturer;
	private double price;
	private String mfgdate;
	private String expdate;
	public Medicine() {};
	public Medicine(int medid, String medname, String manufacturer, double price, String mfgdate, String expdate) {
		super();
		this.medid = medid;
		this.medname = medname;
		this.manufacturer = manufacturer;
		this.price = price;
		this.mfgdate = mfgdate;
		this.expdate = expdate;
	}
	public int getMedid() {
		return medid;
	}
	public void setMedid(int medid) {
		this.medid = medid;
	}
	public String getMedname() {
		return medname;
	}
	public void setMedname(String medname) {
		this.medname = medname;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getMfgdate() {
		return mfgdate;
	}
	public void setMfgdate(String mfgdate) {
		this.mfgdate = mfgdate;
	}
	public String getExpdate() {
		return expdate;
	}
	public void setExpdate(String expdate) {
		this.expdate = expdate;
	}
	
}
