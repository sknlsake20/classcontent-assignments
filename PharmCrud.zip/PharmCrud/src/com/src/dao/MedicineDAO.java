package com.src.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import com.src.model.Medicine;

public class MedicineDAO implements MedDAO{
	private JdbcTemplate jdbctemp;
	public void setJdbctemp(JdbcTemplate jdbctemp)
	{
		this.jdbctemp=jdbctemp;
		
	}
	@Override
	public int saveMedicine(Medicine m) {
		String query="insert into Medicine values("+m.getMedid()+",'"+m.getMedname()+"','"+m.getPrice()+"','"+m.getManufacturer()+"',"+m.getMfgdate()+"','"+m.getExpdate()+")";
		return jdbctemp.update(query);
	}
	@Override
	public int updateMedicine(Medicine m) {
		String query="update Medicine set Medicinename='"+m.getMedname()+"',Medicineprice="+m.getPrice()+",Manufacturer='"+m.getManufacturer()+" where Medicineid="+m.getMedid();
		return jdbctemp.update(query);
	}
	@Override
	public int deleteMedicine(Medicine m) {
		String query="delete fom Medicine where Medicineid="+m.getMedid();
		return jdbctemp.update(query);
	}
	@Override
	public void displayMedicine() {
		String query="Select * from Medicine";
		
		
	}
}