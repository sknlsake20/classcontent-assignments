package com.src.dao;

import com.src.model.Medicine;

public interface MedDAO {

	public int saveMedicine(Medicine m);
	public int updateMedicine(Medicine m);
	public int deleteMedicine(Medicine m);
	public void displayMedicine();
}