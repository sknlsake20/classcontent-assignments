package com.src;
import java.util.List;
import java.util.Scanner;

public class BookMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int choice=0;
		do {
			System.out.println("1  Insert");
			System.out.println("2  Select");
			System.out.println("3  Display");
			System.out.println("4  Delete");
			System.out.println("5  Update");
			System.out.println("6  Exit");
			System.out.println("Enter Your Choice:");
			choice=sc.nextInt();sc.nextLine();
			BookInterface bdao=new BookDAO();
			switch(choice) {
			case 1:
				System.out.println("Enter the Details:");
				Book b=new Book();
				b.setSerialNumber(sc.nextLong());sc.nextLine();
				b.setBookName(sc.nextLine());
				b.setBookAuthor(sc.nextLine());
				b.setBookCost(sc.nextDouble());sc.nextLine();
				bdao.insertBook(b);	
				System.out.println("Updated Sucessfully");
				break;
			case 2:
				System.out.println("Enter The Book Serial Number");
				long SerialNumber=sc.nextLong();
				Book b1=bdao.selectBook(SerialNumber);
				System.out.println(b1.getSerialNumber()+" | "+b1.getBookName()+" | "+b1.getBookAuthor()+" | "+b1.getBookCost());
				break;
			case 3:
				List<Book> book=bdao.selectAllBook();
				book.stream().forEach(System.out::println);
				break;
			case 4:
				System.out.println("Enter The Book Serial Number");
				long Serialnumber=sc.nextLong();
				if(bdao.deleteBook(Serialnumber)==true) {
					System.out.println("Deleted Sucessfully");
				}
				else {
					System.out.println("Book doesn't Exist");
				}
				break;
			case 5:
				System.out.println("Enter The BookName For Updating");
				String name=sc.nextLine();
				if(bdao.updateBook(name)==true) {
					System.out.println("Updated Sucessfully");
				}
				else {
					System.out.println("Book doesn't Exist");
				}
				break;
			case 6:
				System.exit(0);
				break;	
			}
		}while(choice<=6&&choice>=1);

	}

}