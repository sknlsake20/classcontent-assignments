package com.src;

import java.sql.Connection;
import java.sql.SQLException;

public interface EmpImp<Employee> {
public boolean delete(int id);
public Employee selectEmp(int id) throws ClassNotFoundException;

public void update(int id);
public void display() throws SQLException;
void insert(com.src.Employee e) throws SQLException, ClassNotFoundException;

}