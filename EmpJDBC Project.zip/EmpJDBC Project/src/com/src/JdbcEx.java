package com.src;

import java.util.Scanner;

public class JdbcEx {

	public static void main(String[] args) throws Exception {
		int c;
		EmpDAO ed=new EmpDAO();
		Scanner s=new Scanner(System.in);
		System.out.println("1. Insert\n2. Search\n3. Delete\n4.Display\n5. Update\n6. Quit\n\n ");
		System.out.println("Enter the Choice");
		c=s.nextInt();
		switch(c) {
		case 1: 
			System.out.println("Enter the employee  id, name, DOB, Salary, DOJ, DOE, Designation ID, RM, 1 by 1");
			Scanner sc=new Scanner(System.in);
			Employee e=new Employee(sc.nextInt(),sc.nextLine(),sc.nextLine(),sc.nextDouble(),sc.next(),sc.next(),sc.nextInt(),sc.nextInt());
			break;
		case 2:
			System.out.println("Enter the id to display");
			int id=new Scanner(System.in).nextInt();
			Employee em=ed.selectEmp(id);
			System.out.println(em);
			break;
		case 3: 
		
			
			break;
		
		case 4:
			ed.display();
			break;
		case 5:
			break;
		case 6:
			System.exit(0);
			break;
		}
	}

}
