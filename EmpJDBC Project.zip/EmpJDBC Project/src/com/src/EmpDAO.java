package com.src;
import java.sql.*;
import java.util.Scanner;
class Employee {
private int employeeid;
private String employeename;
private String dob;
private double salary;
private String doj;
private String doe;
private int desid;
private int rm;
public String toString() {
	return employeeid+" | "+employeename+" | "+dob+" | "+ salary+" | "+ doj+" | "+ doe+" | "+ desid+" | "+ rm;
}
public Employee() {}
public Employee(int employeeid, String employeename, String dob, double salary, String doj, String doe, int desid,int rm) {
	this.employeeid = employeeid;
	this.employeename = employeename;
	this.dob = dob;
	this.salary = salary;
	this.doj = doj;
	this.doe = doe;
	this.desid = desid;
	this.rm = rm;
}
public int getEmployeeid() {
	return employeeid;
}
public void setEmployeeid(int employeeid) {
	this.employeeid = employeeid;
}
public String getEmployeename() {
	return employeename;
}
public void setEmployeename(String employeename) {
	this.employeename = employeename;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getDoj() {
	return doj;
}
public void setDoj(String doj) {
	this.doj = doj;
}
public String getDoe() {
	return doe;
}
public void setDoe(String doe) {
	this.doe = doe;
}
public int getDesid() {
	return desid;
}
public void setDesid(int desid) {
	this.desid = desid;
}
public int getRm() {
	return rm;
}
public void setRm(int rm) {
	this.rm = rm;
}
}
public class EmpDAO implements EmpImp {
@Override
public void insert(Employee e) throws SQLException, ClassNotFoundException
	{
	String q="insert into employee values(?,?,?,?,?,?,?,?)";
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con;
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Employee","root","ssrr1addictz");
			PreparedStatement ps=con.prepareStatement(q);
		ResultSet rs=ps.executeQuery();
		ps.setInt(1,e.getEmployeeid());
		ps.setString(2, e.getEmployeename());
		ps.setString(3, e.getDob());
		ps.setDouble(4,e.getSalary());
		ps.setString(5,e.getDoj());
		ps.setString(6, e.getDoe());
		ps.setInt(7, e.getDesid());
		ps.setInt(8, e.getRm());
		}	
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	@Override
	public void update(int id) {
		// TODO Auto-generated method stub
		
	}
	@Override 
	public void display() throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con;
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Employee","root","ssrr1addictz");
		Statement st;
		st = con.createStatement();
		ResultSet rs=st.executeQuery("select * from employee");
		st.close();
		con.close();
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
@Override
public Employee selectEmp(int id) throws ClassNotFoundException {
		Employee e=null;
		String q="select * from Employee where id=?";
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","ssrr1addictz");
			PreparedStatement pstmt=con.prepareStatement(q);
			pstmt.setInt(1,id);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				e=new Employee();
				e.setEmployeeid(id);
				e.setEmployeename(rs.getString(2));
				e.setDob(rs.getString(3));
				e.setSalary(rs.getDouble(4));
				e.setDoj(rs.getString(5));
				e.setDoe(rs.getString(6));
				e.setRm(rs.getInt(8));
				e.setDesid(rs.getInt(7));			
				}
		
		}catch(SQLException se) { se.printStackTrace(); }
		return e;
}

@Override
public boolean delete(int id) {

	/*String q="delete from Employee where id=?";
	try(Connection con= getConnection()){
		Statement pstmt=con.prepareStatement(q);
		pstmt.setInt(1,id);
		ResultSet rs=pstmt.executeQuery();
		if() {*/
	return true;
}
}