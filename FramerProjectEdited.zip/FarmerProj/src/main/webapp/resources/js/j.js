/**
 * 
 */
function ValidateForm()
{
	var a= document.myform.auname.value;
	var b= document.myform.apwd.value;
	if(a==null || a=="")
	{
		alert('enter username to login');
		return false;
	}
	else if(b==null || b=="")
	{
		alert('enter password to login');
		return false;
	}
	else
	{
		return true;
	}
}