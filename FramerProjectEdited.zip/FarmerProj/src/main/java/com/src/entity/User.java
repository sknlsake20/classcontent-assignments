package com.src.entity;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="studentlogin")
public class User {
	    @Column(name = "stuname")
	    private String stuname;
	    @Id
	    @Column(name = "stuusername")
	    private java.lang.String stuusername;
        
	    @Column(name = "stupssword")
	    private String stupassword;
	    @Column(name = "stuphno")
	    private long stuphno;
	    @Column(name = "stuaddress")
	    private String stuaddress;

	    @Column(name = "stupincode")
	    private long stupincode;

		@Override
		public String toString() {
			return "User [stuname=" + stuname + ", stuusername=" + stuusername + ", stupassword=" + stupassword
					+ ", stuphno=" + stuphno + ", stuaddress=" + stuaddress + ", stupincode=" + stupincode + "]";
		}

		public String getStuname() {
			return stuname;
		}

		public void setStuname(String stuname) {
			this.stuname = stuname;
		}

		public String getStuusername() {
			return stuusername;
		}

		public void setStuusername(String stuusername) {
			this.stuusername = stuusername;
		}

		public String getStupassword() {
			return stupassword;
		}

		public void setStupassword(String stupassword) {
			this.stupassword = stupassword;
		}

		public long getStuphno() {
			return stuphno;
		}

		public void setStuphno(long stuphno) {
			this.stuphno = stuphno;
		}

		public String getStuaddress() {
			return stuaddress;
		}

		public void setStuaddress(String stuaddress) {
			this.stuaddress = stuaddress;
		}

		public long getStupincode() {
			return stupincode;
		}

		public void setStupincode(long stupincode) {
			this.stupincode = stupincode;
		}

		public User(String stuname, String stuusername, String stupassword, long stuphno, String stuaddress,
				long stupincode) {
			super();
			this.stuname = stuname;
			this.stuusername = stuusername;
			this.stupassword = stupassword;
			this.stuphno = stuphno;
			this.stuaddress = stuaddress;
			this.stupincode = stupincode;
		}

		public User() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
	    
}
