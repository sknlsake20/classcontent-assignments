package com.src.entity;

public class Admin {

}
