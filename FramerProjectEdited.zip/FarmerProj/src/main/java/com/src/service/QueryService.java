package com.src.service;

import java.util.List;

import java.util.Optional;

import com.src.entity.Query;



public interface QueryService {
	public List < Query > getCustomers();

    public void saveCustomer(Query theQuery);

    public Optional<Query> getCustomer(int theId);

    public void deleteCustomer(Query theQuery);

}
