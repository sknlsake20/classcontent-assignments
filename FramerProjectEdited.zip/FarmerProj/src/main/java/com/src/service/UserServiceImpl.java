package com.src.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.UserDao;
import com.src.entity.User;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    UserDao userDAO;
	@Override
	@Transactional
	public void saveCustomer(User theUser) {
		userDAO.save(theUser);
		
	}
}
