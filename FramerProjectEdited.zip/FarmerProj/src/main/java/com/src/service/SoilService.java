package com.src.service;

import java.util.Optional;

import com.src.entity.Soil;

public interface SoilService {
	public void saveSoil(Soil theSoil);
	public Optional<Soil> getCustomer(String theId);
}
