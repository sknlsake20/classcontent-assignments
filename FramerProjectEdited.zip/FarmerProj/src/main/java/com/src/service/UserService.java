package com.src.service;


import com.src.entity.User;

public interface UserService {
	public void saveCustomer(User theUser);
}
