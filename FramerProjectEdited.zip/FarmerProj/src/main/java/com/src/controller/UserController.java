package com.src.controller;


import javax.servlet.http.HttpServletRequest;


import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.FarmerProjApplication;
import com.src.entity.Crop;
import com.src.entity.Query;
import com.src.entity.Soil;
import com.src.entity.User;
import com.src.service.UserService;
import com.src.service.QueryService;
import com.src.service.SoilService;
import com.src.service.CropService;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
@Controller
public class UserController {
	private static final Logger LOGGER = LogManager.getLogger(FarmerProjApplication.class);
	@Autowired DataSource datasource1;
	@Autowired UserService userservice;
	@Autowired QueryService queryservice;
	@Autowired SoilService soilservice;
	@Autowired CropService cropservice;
		@RequestMapping("/userlogin")
		public String user()
		{
			LogManager.getLogger(FarmerProjApplication.class);
			return "loginuser";
		}
		
		@RequestMapping("/submituser")
		public String userenter(HttpServletRequest req,Model m)
		{
			String u=req.getParameter("uname");
			String p=req.getParameter("pwd");

			java.sql.Connection con=null;
		    try {
		    	
		    	con= datasource1.getConnection();
				String query="select * from studentlogin where stuusername=? and stupssword=?";
		    	 PreparedStatement ps=con.prepareStatement(query);
				 ps.setString(1, u);
				 ps.setString(2, p);
				 ResultSet rs=ps.executeQuery();
				 if(rs.next())
				 {
					 LogManager.getLogger(FarmerProjApplication.class);
					 return "displayuser";
				 }
	        else
			 {
				 m.addAttribute("msg","Invalid username and password");
				 LogManager.getLogger(FarmerProjApplication.class);
				   return "error";
			 }
		    }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		    }
		    return null;
		    
		}
		
		@RequestMapping("/userregister")
		public String register(Model m)
		{
			User theUser=new User();
			m.addAttribute("uss",theUser);
			LogManager.getLogger(FarmerProjApplication.class);
			return "registeruser";
		}
		
		@RequestMapping("/registeruser")
		public String add(@ModelAttribute("uss")User theUser,Model m)
		{
			userservice.saveCustomer(theUser);
			m.addAttribute("msg3","registered sucessfully");
			LogManager.getLogger(FarmerProjApplication.class);
			return "NewFile";
		}
		
		@RequestMapping("/query")
		public String studentquery(Model m)
		{
			Query theQuery=new Query();
			m.addAttribute("query",theQuery);
			LogManager.getLogger(FarmerProjApplication.class);
			return "addquery";
		}
		
		@RequestMapping("/querysubmit")
		public String querysubmit(@ModelAttribute("query") Query theQuery,Model m)
		{
			queryservice.saveCustomer(theQuery);
				m.addAttribute("msg1","query submitted successfully");
				LogManager.getLogger(FarmerProjApplication.class);
				return "successquery";
		}
		
		@RequestMapping("/disquery")
		public String displayquery(Model m)
		{
			List<Query> theQuery=queryservice.getCustomers();
			m.addAttribute("stuquery",theQuery);
			LogManager.getLogger(FarmerProjApplication.class);
			return "displayquery";
		}
		
		@RequestMapping("/soil")
		public String Soilstu()
		{
			LogManager.getLogger(FarmerProjApplication.class);
			return "entersoil";
		}
		
		@RequestMapping("/submitdistrict")
		public String districtsubmit(HttpServletRequest req,Model m)
		{
			String district=req.getParameter("soilname");
			Optional<Soil> theSoil=soilservice.getCustomer(district);
			String dist=theSoil.get().getDistrict();
			String soil=theSoil.get().getSoiltype();
			m.addAttribute("dist",dist);
			m.addAttribute("soil",soil);
			LogManager.getLogger(FarmerProjApplication.class);
			return "viewsoiltype";
		}
		
		@RequestMapping("/cropss")
		public String Cropstu()
		{
			LogManager.getLogger(FarmerProjApplication.class);
			return "entercrop";
		}
		
		@RequestMapping("/submitcropss")
		public String cropssubmit(HttpServletRequest req,Model m)
		{
			String type=req.getParameter("croptype");
			Optional<Crop> theCrop=cropservice.getCustomer(type);
			String ct=theCrop.get().getCroptype();
			String cn=theCrop.get().getCropnames();
			String cs=theCrop.get().getCropsoil();
			m.addAttribute("ct",ct);
			m.addAttribute("cn",cn);
			m.addAttribute("cs",cs);
			LogManager.getLogger(FarmerProjApplication.class);
			return "viewcroptype";
		}

}
