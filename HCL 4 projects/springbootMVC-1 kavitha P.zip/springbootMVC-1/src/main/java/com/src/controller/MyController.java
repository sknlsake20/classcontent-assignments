package com.src.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.src.entity.Customer;
import com.src.service.CustomerService;


@Controller
public class MyController {
	
	@RequestMapping("/")
	public String display()
	{
		return "display";
	}
	
	@RequestMapping("/login")
	public String login()
	{
		return "login";
	}
	
	
	@RequestMapping("/check")
	public String checking(HttpServletRequest req,Model m) {
	 String u=req.getParameter("customername");
	 String p=req.getParameter("pwd");
	 if(u.equals(p))
	 {
		 m.addAttribute("user",u);
		 return "redirect:/order/list";
	 }
	 else
	 {
		 m.addAttribute("msg","invalid username and password");
		 return "error";
	 }
	}
	
	@Autowired
    private CustomerService customerService;
    
	@RequestMapping("/add")
	public String add(Model m)
	{
		Customer c=new Customer();
		m.addAttribute("customer",c);
		
		return "registercustomer";
	}

	@RequestMapping("/saveCustomer")
	public String saveCustomer(@ModelAttribute("customer")Customer c)
	{
		customerService.saveCustomer(c);
        return "login";
	}
    



}

