package com.src.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.OrderDAO;
import com.src.entity.Order;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
    private OrderDAO orderDAO;

    @Override
    @Transactional
    public List < Order > getOrders() {
        return (List<Order>) orderDAO.findAll();
    }

    @Override
    @Transactional
    public void saveOrder(Order theorder) {
        orderDAO.save(theorder);
    }

    @Override
    @Transactional
    public Optional<Order> getOrder(int theOrderid) {
        return orderDAO.findById(theOrderid);
    }

    @Override
    @Transactional
    public void deleteOrder(Order theorder) {
        orderDAO.delete(theorder);
    }
}

