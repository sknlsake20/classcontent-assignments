package com.src.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="orderfood")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "orderid")
    private int orderid;
    
    @Column(name = "orderdate")
    private String orderdate;

    @Column(name = "orderfoodname")
    private String orderfoodname;

    @Column(name = "orderprice")
    private double orderfoodprice;

    @Column(name = "orderquantity")
    private int orderfoodquantity;

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public String getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}

	public String getOrderfoodname() {
		return orderfoodname;
	}

	public void setOrderfoodname(String orderfoodname) {
		this.orderfoodname = orderfoodname;
	}

	public double getOrderfoodprice() {
		return orderfoodprice;
	}

	public void setOrderfoodprice(double orderfoodprice) {
		this.orderfoodprice = orderfoodprice;
	}

	public int getOrderfoodquantity() {
		return orderfoodquantity;
	}

	public void setOrderfoodquantity(int orderfoodquantity) {
		this.orderfoodquantity = orderfoodquantity;
	}

	@Override
	public String toString() {
		return "Order [orderid=" + orderid + ", orderdate=" + orderdate + ", orderfoodname=" + orderfoodname
				+ ", orderfoodprice=" + orderfoodprice + ", orderfoodquantity=" + orderfoodquantity + "]";
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

    
    
   
}
