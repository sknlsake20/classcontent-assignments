package com.src.service;

import java.util.List;
import java.util.Optional;

import com.src.entity.Order;

public interface OrderService {
	public List < Order > getOrders();

    public void saveOrder(Order theorder);

    public Optional<Order> getOrder(int theOrderid);

    public void deleteOrder(Order theorder);


}
