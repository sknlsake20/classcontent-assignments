package com.src.controller;

	import java.util.List;
	import java.util.Optional;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.ModelAttribute;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestParam;

	import com.src.entity.Order;
	import com.src.service.OrderService;

	@Controller
	@RequestMapping("/order")
	public class OrderController {


	    @Autowired
	    private OrderService orderService;
	    
	    
	    @GetMapping("/list")
	    public String listCustomers(Model theModel) {
	        List < Order > theorders = orderService.getOrders();
	        System.out.println(theorders);
	        theModel.addAttribute("theorder", theorders);
	        return "order";
	    }

	    @GetMapping("/showForm")
	    public String showFormForAdd(Model theModel) {
	        Order theorder = new Order();
	        theModel.addAttribute("theorder", theorder);
	        return "home";
	    }

	    @PostMapping("/saveOrder")
	    public String saveCustomer(@ModelAttribute("theorder") Order theorder) {
	        orderService.saveOrder(theorder);
	        System.out.println(theorder);
	        return "redirect:/order/list";
	    }

	    @GetMapping("/updateForm")
	    public String showFormForUpdate(@RequestParam("Orderid") int theOrderid,Model theModel) {
	        Optional<Order> theorder = orderService.getOrder(theOrderid);
	        theModel.addAttribute("theorder", theorder);
	        return "redirect:/order/list";
	    }

	    @GetMapping("/delete")
	    public String deleteCustomer(@RequestParam("orderid") int theOrderid) {
	    	Order o =new Order();
	    	o.setOrderid(theOrderid);
	        orderService.deleteOrder(o);
	        return "redirect:/order/list";
	    }
	    
	    @RequestMapping("/payment")
		public String payment()
		{
			return "payment";
		}
		
		@RequestMapping("/success")
		public String finish()
		{
			return "success";
		}
	}


