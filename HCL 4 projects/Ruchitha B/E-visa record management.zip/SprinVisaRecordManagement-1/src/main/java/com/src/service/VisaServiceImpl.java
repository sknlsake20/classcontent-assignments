package com.src.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
import com.src.dao.EmployeeDAO;
import com.src.entity.Employee;

@Service
public class VisaServiceImpl implements VisaService {
	@Autowired
    private EmployeeDAO employeeDAO;

	@Override
	public List<Employee> getEmployee() {
		 return (List<Employee>) employeeDAO.findAll();
	}

	@Override
	@Transactional
	public void saveEmployee(Employee theemployee) {
		employeeDAO.save(theemployee);
		
	}

	@Override
	@Transactional
	public Optional<Employee> getEmployee(int theId) {
		 return employeeDAO.findById(theId);
	}

	@Override
	@Transactional
	public void deleteEmployee(Employee theemployee) {
		 employeeDAO.delete(theemployee);
		
	}

}
