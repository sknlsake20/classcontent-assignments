package com.src.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.src.entity.Employee;
import com.src.service.VisaService;

@Controller
@RequestMapping("/employee")
public class VisaController {
	Logger logger = LoggerFactory.getLogger(MyController.class);
	@Autowired
	private VisaService visaService;
	
    @GetMapping("/list")
    public String listCustomers(Model theModel) {
    	logger.info("list of employee page is accessed");
        List < Employee > theemployee = visaService.getEmployee();
        
        theModel.addAttribute("employee", theemployee);
        return "list-employee";
    }

    @GetMapping("/showForm")
    public String showFormForAdd(Model theModel) {
    	logger.info("Form to show new employee is accessed");
    	Employee theemployee = new Employee();
        theModel.addAttribute("employee", theemployee);
        return "employee-form";
    }

    

	@PostMapping("/saveEmployee")
    public String saveEmployee(@ModelAttribute("employee") Employee theemployee) {
		logger.info("save employee is accessed");
        visaService.saveEmployee(theemployee);
        return "redirect:/employee/list";
    }

    @GetMapping("/updateForm")
    public String showFormForUpdate(@RequestParam("employeeId") int theId,
        Model theModel) {
    	logger.info("Form to update employee is accessed");
        Optional<Employee> theemployee = visaService.getEmployee(theId);
        theModel.addAttribute("customer", theemployee);
        return "employee-form";
    }

    @GetMapping("/delete")
    public String deleteEmployee(@RequestParam("employeeId") int theId) {
    	logger.info("Form to delete employee is accessed");
    	Employee e =new Employee();
    	e.setId(theId);
        visaService.deleteEmployee(e);
        return "redirect:/employee/list";
    }

}
