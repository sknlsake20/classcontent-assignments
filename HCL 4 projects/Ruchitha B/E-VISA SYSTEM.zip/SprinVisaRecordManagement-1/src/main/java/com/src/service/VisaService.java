package com.src.service;

import java.util.List;
import java.util.Optional;

import com.src.entity.Employee;

public interface VisaService {
    public List < Employee > getEmployee();

    public void saveEmployee(Employee theemployee);

    public Optional<Employee> getEmployee(int theId);

    public void deleteEmployee(Employee theemployee);

}
