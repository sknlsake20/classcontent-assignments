package com.example;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.repository.HouseRepository;
import com.example.service.HouseService;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class SpringBootHrmApplicationTests {
	@Mock
	private HouseRepository houserepository;
	
	@InjectMocks
	private HouseService houseservice;
	
	@Test
	public void deleteHouse()
	{
		int id=2;
		houseservice.deleteHouse(id);
		
		verify(houserepository, times(1));
		
		
		
	}

}
