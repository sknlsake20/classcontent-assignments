package com.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.model.House;

public interface HouseRepository extends CrudRepository<House, Integer> {

}
