package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.repository.HouseRepository;

@Controller
public class logincontroller {
		
	@Autowired
	private HouseRepository houserepo;
	@RequestMapping("/")
	public String login()
	{
		return "login";
	}
	@RequestMapping("/login")
	public String logout()
	{
		return "login";
	}
	
}
