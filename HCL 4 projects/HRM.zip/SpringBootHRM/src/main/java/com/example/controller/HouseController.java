package com.example.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.example.model.House;
import com.example.service.HouseService;

@Controller
@RequestMapping(value="/house")
public class HouseController {
	
	@Autowired
	HouseService houseService;
	
	 @RequestMapping(value="/")
	 public String login()
	 {
		 return "login";
	 }
	
	@RequestMapping(value="/list", method=RequestMethod.GET)
	public ModelAndView list() {
		
		ModelAndView model = new ModelAndView("houselist");
		List<House> houseList = houseService.getAllHouses();
		model.addObject("houseList",houseList);
		
		return model;
	}
 @RequestMapping(value="/addHouse/", method=RequestMethod.GET)
 public ModelAndView addHouse() {
	 
	 ModelAndView model = new ModelAndView();
	 House house = new House();
	 model.addObject("houseForm",house);
	 model.setViewName("houseform");
	 
	 return model;
 }
 
 @RequestMapping(value="/editHouse/{id}", method=RequestMethod.GET)
 public ModelAndView editHouse(@PathVariable int id) {
	 ModelAndView model = new ModelAndView();
	 House house = houseService.getHouseById(id);
	 model.addObject("houseForm",house);
	 model.setViewName("houseform");
	 
	 return model;
	 
 }
 
 @RequestMapping(value="/addHouse", method=RequestMethod.POST)
 public ModelAndView add(@ModelAttribute("houseForm") House house)
 {
	 houseService.addHouse(house);
	 return new ModelAndView("redirect:/house/list");
 }
 @RequestMapping(value="/deleteHouse/{id}", method=RequestMethod.GET)
 public ModelAndView delete(@PathVariable("id") int id) {
	 houseService.deleteHouse(id);
	 return new ModelAndView("redirect:/house/list");
 }
 
}
