package com.example.service;

import java.util.List;

import com.example.model.House;

public interface HouseService {
	
	public List<House> getAllHouses();
	public House getHouseById(int id);
	public void addHouse(House house);
	public void deleteHouse(int id);
}
