package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.model.House;
import com.example.repository.HouseRepository;

@Service
@Transactional
public class HouseServiceImplementation implements HouseService {
		
	@Autowired
	HouseRepository houseRepository;

	@Override
	public List<House> getAllHouses() {
		
		return (List<House>) houseRepository.findAll();
	}

	@Override
	public House getHouseById(int id) {
		
		return houseRepository.findById(id).get();
	}

	@Override
	public void addHouse(House house) {
		houseRepository.save(house);
		
	}

	@Override
	public void deleteHouse(int id) {
		houseRepository.deleteById(id);
		
	}
}
