package com.example.kalkimegha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@ComponentScans({
	@ComponentScan("com.src.controller"),
	@ComponentScan("com.src.service")
})
@EntityScan("com.src.entity")
@EnableJpaRepositories("com.src.dao")
@SpringBootApplication
public class MainprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainprojectApplication.class, args);
	}

}
