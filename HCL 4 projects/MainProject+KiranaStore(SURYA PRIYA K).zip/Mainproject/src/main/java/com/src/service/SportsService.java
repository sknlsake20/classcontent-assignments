package com.src.service;

import java.util.List;
import java.util.Optional;

public interface SportsService<Athlete> {

	 public List < Athlete> getAthlete();

	    
	    public Optional<Athlete> getAthlete(int theId); 

		 public void saveAthlete(Athlete theAthlete);


		 public void deleteAthlete(Athlete theAthlete);


		void saveAthlete(Athlete theAthlete);

	

	
	
	
}



