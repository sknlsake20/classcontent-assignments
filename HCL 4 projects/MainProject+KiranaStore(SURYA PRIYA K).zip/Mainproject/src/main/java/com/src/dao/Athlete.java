package com.src.dao;

public class Athlete {

}
