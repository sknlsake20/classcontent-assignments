package com.src.controller;

public class UploadFile {

	public void setFileName(String originalFilename) {
		// TODO Auto-generated method stub
		
	}

	public void setData(byte[] bytes) {
		// TODO Auto-generated method stub
		
	}

}
