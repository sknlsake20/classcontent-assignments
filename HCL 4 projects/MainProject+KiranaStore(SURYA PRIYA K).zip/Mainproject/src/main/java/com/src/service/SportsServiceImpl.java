package com.src.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.SportsHealthDAO;

public class SportsServiceImpl<Athlete>  implements SportsService{

	@Autowired
    private SportsHealthDAO sportshealthDAO;

    @Override
    @Transactional
    public List < Athlete > getAthlete() {
        return (List<Athlete>) sportshealthDAO.findAll();
        

    }

	@Override
    @Transactional
    public <sportshealthDAO> void saveAthlete(Athlete theAthlete) {
        SportsHealthDAO.save(theAthlete);
    }

    @Override
    @Transactional
    public Optional<Athlete> getAthlete(int theId) {
        return sportshealthDAO.findById(theId);
    }

    @Override
    @Transactional
    public void deleteAthlete(Athlete theAthlete) {
        sportshealthDAO.delete(theAthlete);
    }

	
}
