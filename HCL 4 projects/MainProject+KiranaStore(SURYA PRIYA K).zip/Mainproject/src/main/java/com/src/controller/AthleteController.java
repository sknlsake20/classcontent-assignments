package com.src.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/athlete")
public class AthleteController<AthleteService, Athlete> {

    @Autowired
    private AthleteService athleteService;
    
    
    @GetMapping("/list")
    public <Athlete> String listCustomers(Model theModel) {
        List < Athlete> theAthletes = ( athleteService).getAthlete();
        
        Object theAthlete;
		theModel.addAttribute("Ahtlete", theAthlete);
        return "list-customers";
    }

    @GetMapping("/showForm")
    public String showFormForAdd(Model theModel) {
        Athlete theAthlete = new Athlete();
        theModel.addAttribute("athlete", theAthlete);
        return "athlete-form";
    }

    @PostMapping("/saveAthlete")
    public String saveAthlete(@ModelAttribute("athlete") Athlete theAthlete) {
        athleteService.saveAthlete(theAthlete);
        return "redirect:/athlete/list";
    }

    @GetMapping("/updateForm")
    public String showFormForUpdate(@RequestParam("athleteId") int theId,
        Model theModel) {
        Optional<Athlete> theAthlete = athleteService.getAthlete(theId);
        theModel.addAttribute("athlete", theAthlete);
        return "customer-form";
    }

    @GetMapping("/delete")
    public String deleteAthlete(@RequestParam("AthleteId") int theId) {
    Athlete a =new Athlete();
    	a.setId(theId);
        athleteService.deleteAthlete(a);
        return "redirect:/athlete/list";
    }
}


