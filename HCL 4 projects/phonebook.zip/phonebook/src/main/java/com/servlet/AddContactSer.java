package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.conn.DbConnect;
import com.dao.contactDAO;
import com.entity.contact;

@WebServlet("/AddContact")
public class AddContactSer extends HttpServlet {


		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			int userId=Integer.parseInt(req.getParameter("userId"));
			String name=req.getParameter("name");
			String email=req.getParameter("email");

			String phno=req.getParameter("phno");

			String about=req.getParameter("about");
			
			contact c=new contact(name,email,phno,about,userId);
			contactDAO dao=new contactDAO(DbConnect.getConn());
			
			HttpSession session=req.getSession();
			boolean f=dao.saveContact(c);
			if(f)
			{
				session.setAttribute("succMsg", "your contact saved");
				resp.sendRedirect("AddContact.jsp");
			}
			else {
				session.setAttribute("failedMsg", "something wrong");
				resp.sendRedirect("AddContact.jsp");
			}
		}
			
}
