package com.src.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.src.entity.Product;


@Repository
public interface ProductDAO extends CrudRepository<Product,Integer>{

}
