package com.src.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customers1")
public class Customer {
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name = "id")
	private int customerid;
	 
	 @Column(name = "Username")
	private String username;
	 
	 @Column(name = "Password")
	private String password;
	 
	 @Column(name = "MailID")
	private String mailid;
	 
	 @Column(name = "MobileNo")
	private long mobileno;
	 
	 @Column(name = "Address")
	private String address;
	 
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int theId) {
		this.customerid = theId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public long getMobileno() {
		return mobileno;
	}
	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Customer(int customerid, String username, String password, String mailid, long mobileno, String address) {
		super();
		this.customerid = customerid;
		this.username = username;
		this.password = password;
		this.mailid = mailid;
		this.mobileno = mobileno;
		this.address = address;
	}
	public Customer() {
		super();
	}
	
}