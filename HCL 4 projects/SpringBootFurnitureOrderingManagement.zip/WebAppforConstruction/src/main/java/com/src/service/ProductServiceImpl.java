package com.src.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.src.dao.ProductDAO;
import com.src.entity.Product;

@Service
public class ProductServiceImpl implements ProductService {
	
	
	@Autowired
    private ProductDAO productDAO;
	
	@Override
	@Transactional
	public Optional<Product> getProduct(int theId) {
		// TODO Auto-generated method stub
		return productDAO.findById(theId);
	}

	@Override
	@Transactional
	public void deleteProduct(Product theProduct) {
		// TODO Auto-generated method stub
		productDAO.delete(theProduct);
		
	}

	@Override
	@Transactional
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return (List<Product>) productDAO.findAll();
	}

	@Override
	@Transactional
	public void saveProduct(Product theProduct) {
		// TODO Auto-generated method stub
		productDAO.save(theProduct);
	}
}
