package com.src.service;
import java.util.List;
import java.util.Optional;

import com.src.entity.Product;

public interface ProductService{
	

	    public List < Product > getProducts();

	    public void saveProduct(Product theProduct);

	    public Optional<Product> getProduct(int theId);

	    public void deleteProduct(Product theProduct);

	}
