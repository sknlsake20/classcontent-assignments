package com.src.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Dose2")
public class Dose2 {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "dose2id")
private int dose2id;
	@Column(name = "dateofd2")
private String dateofd2;
	@Column(name = "vaccineid")
private int vaccineid;
	@Column(name = "employeeid")
private int employeeid;
public Dose2() {
	super();
}
public Dose2(int dose2id, String dateofd1, int vaccineid, int employeeid) {
	super();
	this.dose2id = dose2id;
	this.dateofd2 = dateofd1;
	this.vaccineid = vaccineid;
	this.employeeid = employeeid;
}
public int getdose2id() {
	return dose2id;
}
public void setdose2id(int dose2id) {
	this.dose2id = dose2id;
}
public String getDateofd2() {
	return dateofd2;
}
public void setDateofd1(String dateofd2) {
	this.dateofd2 = dateofd2;
}
public int getVaccineid() {
	return vaccineid;
}
public void setVaccineid(int vaccineid) {
	this.vaccineid = vaccineid;
}
public int getEmployeeid() {
	return employeeid;
}
public void setEmployeeid(int employeeid) {
	this.employeeid = employeeid;
}
}
