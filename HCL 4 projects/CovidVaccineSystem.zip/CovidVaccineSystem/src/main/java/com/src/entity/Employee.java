package com.src.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Employee")
public class Employee {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name = "employeeaddress")
private String employeeaddress;
@Column(name = "employeename")
private String employeename;
@Column(name = "employeeemail")
private String employeeemail;
@Column(name = "gender")
private String gender;
@Column(name = "employeeblood")
private String employeeblood;
@Column(name = "employeephno")
private long employeephno;
@Column(name = "employeedob")
private String employeedob;
@Column(name = "employeepass")
private String employeepass;
public Employee(String employeeemail, String employeename, String employeeaddress, String gender,
		String employeeblood, long employeephno, String employeedob, String employeepass) {
	super();
	this.employeeemail = employeeemail;
	this.employeename = employeename;
	this.employeeaddress = employeeaddress;
	this.gender = gender;
	this.employeeblood = employeeblood;
	this.employeephno = employeephno;
	this.employeedob = employeedob;
	this.employeepass = employeepass;
}

public String getEmployeepass() {
	return employeepass;
}
public void setEmployeepass(String employeepass) {
	this.employeepass = employeepass;
}
public String getEmployeeemail() {
	return employeeemail;
}
public void setEmployeeemail(String employeeemail) {
	this.employeeemail = employeeemail;
}
public String getEmployeename() {
	return employeename;
}
public void setEmployeename(String employeename) {
	this.employeename = employeename;
}
public String getEmployeeaddress() {
	return employeeaddress;
}
public void setEmployeeaddress(String employeeaddress) {
	this.employeeaddress = employeeaddress;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getEmployeeblood() {
	return employeeblood;
}
public void setEmployeeblood(String employeeblood) {
	this.employeeblood = employeeblood;
}
public long getEmployeephno() {
	return employeephno;
}
public void setEmployeephno(long employeephno) {
	this.employeephno = employeephno;
}
public String getEmployeedob() {
	return employeedob;
}
public void setEmployeedob(String employeedob) {
	this.employeedob = employeedob;
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}

}
