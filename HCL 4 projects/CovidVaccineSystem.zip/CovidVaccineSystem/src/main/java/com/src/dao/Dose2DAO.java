package com.src.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.src.entity.Dose2;
@Repository
public interface Dose2DAO extends CrudRepository<Dose2,Integer>{
}