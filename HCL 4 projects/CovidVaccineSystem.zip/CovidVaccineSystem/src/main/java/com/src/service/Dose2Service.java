package com.src.service;
import java.util.List;
import java.util.Optional;
import com.src.entity.Dose2;
public interface Dose2Service {
public List <Dose2> getDose2();

public void saveDose2(Dose2 theDose2);

public Optional <Dose2> getDose2(int theDose2Id);

public void deleteDose2(Dose2 theDose2);

}
