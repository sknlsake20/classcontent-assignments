package com.src.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.src.entity.Dose1;
@Repository
public interface Dose1DAO extends CrudRepository<Dose1,Integer>{
}