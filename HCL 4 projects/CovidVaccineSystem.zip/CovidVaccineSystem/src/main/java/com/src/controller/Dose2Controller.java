package com.src.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.src.entity.Dose2;
import com.src.service.Dose2Service;
@Controller
@RequestMapping("/dose2")
public class Dose2Controller {

	    @Autowired
	    private Dose2Service dose2Service;
	    @GetMapping("/dose2")
	    public String listDose1(Model theModel) {
	    List < Dose2 > theDose1s = dose2Service.getDose2();
	    theModel.addAttribute("dose2s", theDose1s);
        return "dose2";
}
	    @PostMapping("/saveDose2")
	    public String saveDose2(@ModelAttribute("dose2") Dose2 theDose2) {
	        dose2Service.saveDose2(theDose2);
	        return "redirect:/customer/list";
	    }
	    @GetMapping("/updateForm")
	    public String showFormForUpdate(@RequestParam("dose2id") int thedose2Id,Model theModel) 
	    {
	        Optional <Dose2> thedose2 = dose2Service.getDose2(thedose2Id);
	        theModel.addAttribute("dose2", thedose2);
	        return "dose2-form";
	    }
	    @GetMapping("/delete")
	    public String deleteCustomer(@RequestParam("dose2id") int theDose2Id) 
	    {
	    	Dose2 d =new Dose2();
	    	d.setdose2id(theDose2Id);
	        dose2Service.deleteDose2(d);
	        return "redirect:/dose2/list";
	    }
}