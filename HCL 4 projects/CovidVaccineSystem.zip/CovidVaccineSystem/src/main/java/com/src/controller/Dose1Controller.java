package com.src.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.src.entity.Dose1;
import com.src.service.Dose1Service;
@Controller
@RequestMapping("/dose1")
public class Dose1Controller {

	    @Autowired
	    private Dose1Service dose1Service;
	    @GetMapping("/dash1")
	    public String listDose1(Model theModel) {
	    List < Dose1 > theDose1s = dose1Service.getDose1();
	    theModel.addAttribute("dose1s", theDose1s);
        return "dash1";
}
	    @PostMapping("/saveCustomer")
	    public String saveDose1(@ModelAttribute("dose1") Dose1 theDose1) {
	        dose1Service.saveDose1(theDose1);
	        return "redirect:/customer/list";
	    }
	    @GetMapping("/updateForm")
	    public String showFormForUpdate(@RequestParam("dose1id") int thedose1Id,
	        Model theModel) {
	        Optional <Dose1> thedose1 = dose1Service.getDose1(thedose1Id);
	        theModel.addAttribute("dose1", thedose1);
	        return "dose1-form";
	    }
	    @GetMapping("/delete")
	    public String deleteCustomer(@RequestParam("dose1id") int theDose1Id) {
	    	Dose1 d =new Dose1();
	    	d.setDose1id(theDose1Id);
	        dose1Service.deleteDose1(d);
	        return "redirect:/dose1/list";
}
}