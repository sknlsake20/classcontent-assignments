package com.src.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.Dose2DAO;
import com.src.entity.Dose2;
@Service
public class Dose2ServiceImpl implements Dose2Service {
	@Autowired
	private Dose2DAO Dose2DAO;
	@Override
	@Transactional
	public List<Dose2> getDose2() {
		// TODO Auto-generated method stub
			return (List<Dose2>)Dose2DAO.findAll();
	}

	@Override
	@Transactional
	public void saveDose2(Dose2 theDose2) {
		// TODO Auto-generated method stub
		Dose2DAO.save(theDose2);
	}

	@Override
	@Transactional
	public Optional<Dose2> getDose2(int theDose2Id) {
		// TODO Auto-generated method stub
		return Dose2DAO.findById(theDose2Id);
	}

	@Override
	@Transactional
	public void deleteDose2(Dose2 theDose2) {
		Dose2DAO.delete(theDose2);
		// TODO Auto-generated method stub
		
	}
	
}
