package com.src.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Dose1")
public class Dose1 {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "dose1id")
private int dose1id;
	@Column(name = "dateofd1")
private String dateofd1;
	@Column(name = "vaccineid")
private int vaccineid;
	@Column(name = "employeeemail")
private String employeeemail;
public Dose1() {
	super();
}
public Dose1(int dose1id, String dateofd1, int vaccineid, String employeeemail) {
	super();
	this.dose1id = dose1id;
	this.dateofd1 = dateofd1;
	this.vaccineid = vaccineid;
	this.employeeemail = employeeemail;
}
public int getDose1id() {
	return dose1id;
}
public void setDose1id(int dose1id) {
	this.dose1id = dose1id;
}
public String getDateofd1() {
	return dateofd1;
}
public void setDateofd1(String dateofd1) {
	this.dateofd1 = dateofd1;
}
public int getVaccineid() {
	return vaccineid;
}
public void setVaccineid(int vaccineid) {
	this.vaccineid = vaccineid;
}
public String getEmployeeemail() {
	return employeeemail;
}
public void setEmployeeemail(String employeeemail) {
	this.employeeemail = employeeemail;
}
}
