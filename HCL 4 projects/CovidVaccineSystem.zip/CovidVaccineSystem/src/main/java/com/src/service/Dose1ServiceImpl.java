package com.src.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.Dose1DAO;
import com.src.entity.Dose1;
@Service
public class Dose1ServiceImpl implements Dose1Service {
	@Autowired
	private Dose1DAO dose1DAO;
	@Override
	@Transactional
	public List<Dose1> getDose1() {
		// TODO Auto-generated method stub
			return (List<Dose1>)dose1DAO.findAll();
	}

	@Override
	@Transactional
	public void saveDose1(Dose1 theDose1) {
		// TODO Auto-generated method stub
		dose1DAO.save(theDose1);
	}

	@Override
	@Transactional
	public Optional<Dose1> getDose1(int theDose1Id) {
		// TODO Auto-generated method stub
		return dose1DAO.findById(theDose1Id);
	}

	@Override
	@Transactional
	public void deleteDose1(Dose1 theDose1) {
		dose1DAO.delete(theDose1);
		// TODO Auto-generated method stub
		
	}
	
}
