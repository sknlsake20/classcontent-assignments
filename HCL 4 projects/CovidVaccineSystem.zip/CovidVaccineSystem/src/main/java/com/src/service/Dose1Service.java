package com.src.service;
import java.util.List;
import java.util.Optional;
import com.src.entity.Dose1;
public interface Dose1Service {
public List <Dose1> getDose1();

public void saveDose1(Dose1 theDose1);

public Optional <Dose1> getDose1(int theDose1Id);

public void deleteDose1(Dose1 theDose1);

}
