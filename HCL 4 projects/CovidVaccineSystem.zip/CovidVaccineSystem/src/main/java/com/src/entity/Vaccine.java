package com.src.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Vaccine")
public class Vaccine {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "vaccineid")
	private int vaccineid;
	@Column(name = "vaccinename")
	private String vaccinename;
	@Column(name = "manufacturer")
	private String manufacturer;
	@Column(name = "nursename")
	private String nursename;
	@Column(name = "hospitalname")
	private String hospitalname;
	public int getVaccineid() {
		return vaccineid;
	}
	public void setVaccineid(int vaccineid) {
		this.vaccineid = vaccineid;
	}
	public String getVaccinename() {
		return vaccinename;
	}
	public void setVaccinename(String vaccinename) {
		this.vaccinename = vaccinename;
	}

	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public Vaccine(int vaccineid, String vaccinename, String manufacturer, String nursename, String hospitalname) {
		super();
		this.vaccineid = vaccineid;
		this.vaccinename = vaccinename;
		this.manufacturer = manufacturer;
		this.nursename=nursename;
		this.hospitalname=hospitalname;
	}
	public String getNursename() {
		return nursename;
	}
	public void setNursename(String nursename) {
		this.nursename = nursename;
	}
	public String getHospitalname() {
		return hospitalname;
	}
	public void setHospitalname(String hospitalname) {
		this.hospitalname = hospitalname;
	}
	public Vaccine() {
		super();
	}
	
}
