package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScans({
	@ComponentScan("com.src.controller"),
	@ComponentScan("com.src.service")
})
@EntityScan("com.src.entity")
@EnableJpaRepositories("com.src.dao")

public class GallerybootApplication {
	private static final Logger LOGGER = LogManager.getLogger(GallerybootApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(GallerybootApplication.class, args);
		LOGGER.info("Info level log message");
        LOGGER.debug("Debug level log message");
        LOGGER.error("Error level log message");
		
	}

}
