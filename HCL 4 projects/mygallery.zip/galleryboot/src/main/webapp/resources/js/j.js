/**
 * 
 */
function ValidateForm()
{
	var a=document.myform.uname.value;
	var b=document.myform.pwd.value;
	if(a==null || a=="")
	{
		alert("enter username to login");
		return false;
	}
	else if(b==null || b=="")
	{
		alter("enter user password to login");
		return false;
		
	}
	else
	{
		return true;
	}
	
	}
	
	
	
	
	
