package com.src.service;

import java.util.List;
import java.util.Optional;

import com.src.entity.Employee;

public interface EmployeeService {

    public List < Employee > getEmployees();

    public void saveEmployee (Employee theEmployee);

    public Optional<Employee> getEmployee(int theId);

    public void deleteEmployee(Employee theEmployee);

}
