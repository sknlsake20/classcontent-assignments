package com.src.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.EmployeeDAO;
import com.src.entity.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
    private EmployeeDAO employeeDAO;

    @Override
    @Transactional
    public List < Employee > getEmployees() {
        return (List<Employee>) employeeDAO.findAll();
    }

    @Override
    @Transactional
    public void saveEmployee(Employee theEmployee) {
        employeeDAO.save(theEmployee);
    }

    @Override
    @Transactional
    public Optional<Employee> getEmployee(int theId) {
        return employeeDAO.findById(theId);
    }

    @Override
    @Transactional
    public void deleteEmployee(Employee theEmployee) {
        employeeDAO.delete(theEmployee);
    }
}
