package com.src.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.src.entity.Manager;
@Repository
public interface ManagerDAO extends CrudRepository<Manager, Integer> {

}
