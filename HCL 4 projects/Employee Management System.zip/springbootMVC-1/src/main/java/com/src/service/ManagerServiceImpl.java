package com.src.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.ManagerDAO;
import com.src.entity.Manager;

public class ManagerServiceImpl implements ManagerService {


	@Autowired
    private ManagerDAO managerDAO;
	
	@Override
	@Transactional
	public List<Manager> getManagers() {
		return (List<Manager>) managerDAO.findAll();
	}

	@Override
	@Transactional
	public void saveManager(Manager theManager) {
		managerDAO.save(theManager);
	}

	@Override
	@Transactional
	public Optional<Manager> getManager(int theId) {
		return managerDAO.findById(theId);
	}

	@Override
	@Transactional
	public void deleteManager(Manager theManager) {
		managerDAO.delete(theManager);
	}

}
