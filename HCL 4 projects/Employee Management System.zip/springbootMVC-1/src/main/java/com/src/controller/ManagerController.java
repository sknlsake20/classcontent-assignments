package com.src.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.src.entity.Manager;
import com.src.service.ManagerService;

public class ManagerController {
	@Autowired
    private ManagerService managerService;
    
    
    @GetMapping("/list")
    public String list(Model theModel) {
        List < Manager > theManagers = managerService.getManagers();
        
        theModel.addAttribute("managers", theManagers);
        return "list-managers";
    }

    @GetMapping("/showForm")
    public String showFormForAdd(Model theModel) {
        Manager theManager = new Manager();
        theModel.addAttribute("manager", theManager);
        return "manager-form";
    }

    @PostMapping("/saveManager")
    public String saveManager(@ModelAttribute("manager") Manager theManager) {
        managerService.saveManager(theManager);
        return "redirect:/manager/list";
    }

    @GetMapping("/updateForm")
    public String showFormForUpdate(@RequestParam("managerId") int theId,
        Model theModel) {
        Optional<Manager> theManager = managerService.getManager(theId);
        theModel.addAttribute("manager", theManager);
        return "manager-form";
    }

    @GetMapping("/delete")
    public String deleteManager(@RequestParam("managerId") int theId) {
    	Manager m =new Manager();
    	m.setId(theId);
        managerService.deleteManager(m);
        return "redirect:/manager/list";
    }
}
