package com.src.service;

import java.util.List;
import java.util.Optional;

import com.src.entity.Manager;

public interface ManagerService {
	public List <Manager> getManagers();

    public void saveManager (Manager theManager);

    public Optional<Manager> getManager(int theId);

    public void deleteManager(Manager theManager);

	//public List<Manager> getManagers();
}
