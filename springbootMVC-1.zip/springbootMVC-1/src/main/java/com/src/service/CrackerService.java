package com.src.service;

import java.util.List;
import java.util.Optional;

import com.src.entity.Cracker;

public interface CrackerService {

    public List < Cracker > getCrackers();

    public void saveCracker(Cracker theCracker);

    public Optional<Cracker> getCracker(int theId);

    public void deleteCracker(Cracker theCracker);

}
