package com.src.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.CrackerDAO;
import com.src.entity.Cracker;

@Service
public class CrackerServiceImpl implements CrackerService {

	@Autowired
    private CrackerDAO crackerDAO;

    @Override
    @Transactional
    public List < Cracker > getCrackers() {
        return (List<Cracker>) crackerDAO.findAll();
    }

    @Override
    @Transactional
    public void saveCracker(Cracker theCracker) {
        crackerDAO.save(theCracker);
    }

    @Override
    @Transactional
    public Optional<Cracker> getCracker(int theId) {
        return crackerDAO.findById(theId);
    }

    @Override
    @Transactional
    public void deleteCracker(Cracker theCracker) {
        crackerDAO.delete(theCracker);
    }
}
