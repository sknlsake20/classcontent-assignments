package com.src.entity;

import javax.persistence.Column;
import java.sql.Blob;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cracker")
public class Cracker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CRACKERS_ID")
    private int id;

    @Column(name = "CRACKERS_NAME")
    private String name;

    @Column(name = "CRACKERS_TYPE")
    private String type;

    @Column(name = "CRACKERS_QUANTITY")
    private String qty;

    @Column(name = "CRACKERS_MARKET_PRICE")
    private float mp;

    @Column(name = "CRACKERS_OFFER_RATE")
    private float sp;

    @Column(name = "CRACKERS_AVAILABILITY")
    private String avail;
    

	public Cracker() {

    }


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getQty() {
		return qty;
	}


	public void setQty(String qty) {
		this.qty = qty;
	}


	public float getMp() {
		return mp;
	}


	public void setMp(float mp) {
		this.mp = mp;
	}


	public float getSp() {
		return sp;
	}


	public void setSp(float sp) {
		this.sp = sp;
	}


	public String getAvail() {
		return avail;
	}


	public void setAvail(String avail) {
		this.avail = avail;
	}


	@Override
	public String toString() {
		return "Cracker [id=" + id + ", name=" + name + ", type=" + type + ", qty=" + qty + ", mp=" + mp + ", sp=" + sp
				+ ", avail=" + avail + "]";
	}

}
