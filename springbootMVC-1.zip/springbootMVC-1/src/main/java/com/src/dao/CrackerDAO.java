package com.src.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.src.entity.Cracker;
@Repository
public interface CrackerDAO extends CrudRepository<Cracker,Integer>{
  
}
