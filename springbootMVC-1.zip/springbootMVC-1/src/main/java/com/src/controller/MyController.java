package com.src.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class MyController {
	
	@RequestMapping("/")
	public String display()
	{
		return "index";
	}

	@RequestMapping("/Login")
	public String login()
	{
		return "LoginAdmin";
	}
	
	@RequestMapping("/Reg")
	public String register()
	{
		return "Register";
	}
	@RequestMapping("/Db")
	public String database()
	{
		return "Database";
	}
	@RequestMapping("/index")
	public String index()
	{
		return "index";
	}
	
	@RequestMapping("logout")
	public String logout()
	{
		return "redirect:/";
	}

	@RequestMapping("/disp")
	public String disp()
	{
		return "display";
	}
}
