package com.src.controller;
import com.src.service.CropService;
import com.src.service.SoilService;

import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.src.entity.Crop;
import com.src.entity.Soil;

@Controller
public class AdminController {
	@Autowired DataSource datasource;
	@Autowired SoilService soilservice;
	@Autowired CropService cropservice;
	@RequestMapping("/")
	public String display()
	{
		return "index";
	}
	
	@RequestMapping("/adminlogin")
	public String loginadmin()
	{
		return "loginadmin";
	}
	
	@RequestMapping("/submitadmin")
	public String adminenter(HttpServletRequest req,Model m)
	{
		String u=req.getParameter("auname");
		String p=req.getParameter("apwd");
		java.sql.Connection con=null;
	    try {
	    	
	    	con= datasource.getConnection();
			String query="select * from adminlogin where adminusername=? and adminpassword=?";
	    	 PreparedStatement ps=con.prepareStatement(query);
			 ps.setString(1, u);
			 ps.setString(2, p);
			 ResultSet rs=ps.executeQuery();
			 if(rs.next())
			 {
				 return "displayadmin";
			 }
			 else
			 {
				 m.addAttribute("msg","Invalid username and password");
				   return "error";
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return null;
	}
	

	@RequestMapping("/soiladmin")
	public String adminsoil(Model m)
	{
		Soil theSoil=new Soil();
		m.addAttribute("soil",theSoil);
		return "soiladmin";
	}
	
	@RequestMapping("/submitsoil")
	public String submitsoil(@ModelAttribute("soil")Soil theSoil,Model m)
	{
		soilservice.saveSoil(theSoil);
		m.addAttribute("msg3","information added");
		return "success";
	}
	
	@RequestMapping("/cropadmin")
	public String admincrop(Model m)
	{
		Crop theCrop=new Crop();
		m.addAttribute("crop",theCrop);
		return "cropdetails";
	}
	
	@RequestMapping("/detailscrop")
	public String cropfinal(@ModelAttribute("crop")Crop theCrop,Model m)
	{
		cropservice.saveCrop(theCrop);
		m.addAttribute("msg3","information added");
		return "success";
	}
	
	/*@RequestMapping("/updateee/{id}")
	public String updateanswer(@PathVariable("id") int i,Model m)
	{
		StudentQuery sq=sqdao.getquery(i);
		System.out.println(sq);
		m.addAttribute("command",sq);
		return "ans";
	}
	
	@RequestMapping("/ans")
	public String submitans(@ModelAttribute("sq")StudentQuery ss,Model m)
	{
		int i=sqdao.updatequery(ss);
			if(i>0)
			{
				m.addAttribute("msg3","information added");
				return "success";
			}
			else
			{
				return "redirect:/disqueryadmin";
			}
		
	}*/
	

}
