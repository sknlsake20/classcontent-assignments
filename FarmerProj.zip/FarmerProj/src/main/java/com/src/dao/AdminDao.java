package com.src.dao;

public class AdminDao {

}
