package com.src.dao;

import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;

import com.src.entity.Crop;

@Repository
public interface CropDao extends CrudRepository<Crop,java.lang.String>{

}
