package com.src.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "studentqueries")
public class Query {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "qno")
	    private int qno;

	    @Column(name = "studentuser")
	    private String studentuser;

	    @Column(name = "query")
	    private String query;

		public Query(int qno, String studentuser, String query) {
			super();
			this.qno = qno;
			this.studentuser = studentuser;
			this.query = query;
		}

		public Query() {
			
		}

		@Override
		public String toString() {
			return "Query [qno=" + qno + ", studentuser=" + studentuser + ", query=" + query + "]";
		}

		public int getQno() {
			return qno;
		}

		public void setQno(int qno) {
			this.qno = qno;
		}

		public String getStudentuser() {
			return studentuser;
		}

		public void setStudentuser(String studentuser) {
			this.studentuser = studentuser;
		}

		public String getQuery() {
			return query;
		}

		public void setQuery(String query) {
			this.query = query;
		}
	    
	    
}
