package com.src.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="crop")
public class Crop {
    @Id
    @Column(name = "croptype")
    private java.lang.String croptype;
    
    @Column(name = "cropnames")
    private String cropnames;
    
    @Column(name = "cropsoil")
    private String cropsoil;

	public String getCroptype() {
		return croptype;
	}

	public void setCroptype(String croptype) {
		this.croptype = croptype;
	}

	public String getCropnames() {
		return cropnames;
	}

	public void setCropnames(String cropnames) {
		this.cropnames = cropnames;
	}

	public String getCropsoil() {
		return cropsoil;
	}

	public void setCropsoil(String cropsoil) {
		this.cropsoil = cropsoil;
	}

	@Override
	public String toString() {
		return "Crop [croptype=" + croptype + ", cropnames=" + cropnames + ", cropsoil=" + cropsoil + "]";
	}

	public Crop(String croptype, String cropnames, String cropsoil) {
		super();
		this.croptype = croptype;
		this.cropnames = cropnames;
		this.cropsoil = cropsoil;
	}

	public Crop() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
