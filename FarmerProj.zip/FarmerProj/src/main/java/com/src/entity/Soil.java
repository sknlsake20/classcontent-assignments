package com.src.entity;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="soil")
public class Soil {
	@Column(name = "state")
    private String state;
    
    @Id
    @Column(name = "district")
    private java.lang.String district;
    
    @Column(name = "soiltype")
    private String soiltype;

	public Soil() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Soil(String state, String district, String soiltype) {
		super();
		this.state = state;
		this.district = district;
		this.soiltype = soiltype;
	}

	@Override
	public String toString() {
		return "Soil [state=" + state + ", district=" + district + ", soiltype=" + soiltype + "]";
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getSoiltype() {
		return soiltype;
	}

	public void setSoiltype(String soiltype) {
		this.soiltype = soiltype;
	}

}
