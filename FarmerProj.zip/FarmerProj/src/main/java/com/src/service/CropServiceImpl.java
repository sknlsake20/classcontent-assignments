package com.src.service;

import java.util.Optional;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.src.dao.CropDao;
import com.src.entity.Crop;
@Service
public class CropServiceImpl implements CropService{
   @Autowired CropDao cropDAO;
	@Override
	@Transactional
	public void saveCrop(Crop theCrop) {
		cropDAO.save(theCrop);
		
	}

	@Override
	@Transactional
	public Optional<Crop> getCustomer(String theId) {
		return cropDAO.findById(theId);
	}

}
