package com.src.service;

import java.util.Optional;

import com.src.entity.Crop;

public interface CropService {
	public void saveCrop(Crop theCrop);
	public Optional<Crop> getCustomer(String theId);
}
