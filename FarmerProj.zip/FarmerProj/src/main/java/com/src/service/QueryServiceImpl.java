package com.src.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.QueryDao;
import com.src.entity.Query;
@Service
public class QueryServiceImpl implements QueryService{
	@Autowired QueryDao queryDAO;
	@Override
	 @Transactional
	public List<Query> getCustomers() {
		return (List<Query>) queryDAO.findAll();
	}

	@Override
	 @Transactional
	public void saveCustomer(Query theQuery) {
	     queryDAO.save(theQuery);
		
	}

	@Override
	 @Transactional
	public Optional<Query> getCustomer(int theId) {
		return queryDAO.findById(theId);
	}

	@Override
	 @Transactional
	public void deleteCustomer(Query theQuery) {
		queryDAO.delete(theQuery);
		
	}

}
