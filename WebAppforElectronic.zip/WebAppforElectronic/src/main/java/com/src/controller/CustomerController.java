package com.src.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.src.entity.Customer;
import com.src.entity.Product;
import com.src.service.CustomerService;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	

	    @Autowired
	    private CustomerService customerService;
	    
	    @RequestMapping("/")
		public String display()
		{
			return "display";
		}
	    
	    @RequestMapping("/buy")
	    public String Buy
	    (Model theModel) {
	        Customer theCustomer = new Customer();
	        theModel.addAttribute("customer", theCustomer);
	        return "buy";
	    }
	    
	    @RequestMapping("/thankyou")
		public String thankyou()
		{
			return "thanks";
		}

	    @GetMapping("/showForm")
	    public String showFormForAdd(Model theModel) {
	        Customer theCustomer = new Customer();
	        theModel.addAttribute("customer", theCustomer);
	        return "customer-form";
	    }

	    @PostMapping("/saveCustomer")
	    public String saveCustomer(@ModelAttribute("customer") Customer theCustomer) {
	    	customerService.saveCustomer(theCustomer);
	        return "viewproduct";
	        
	    }

	}
