package com.src.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {
	
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name = "Productid")
	private int product_ID;
	
	@Column(name = "Product_name")
	private String product_Name;
	
	
	
	@Column(name = "Product_cost")
	private int product_Cost;
	
	public String getProduct_Name() {
		return product_Name;
	}
	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}
	public int getProduct_ID() {
		return product_ID;
	}
	public void setProduct_ID(int product_ID) {
		this.product_ID = product_ID;
	}
	
	public int getProduct_Cost() {
		return product_Cost;
	}
	public void setProduct_Cost(int product_Cost) {
		this.product_Cost = product_Cost;
	}
	public Product(String product_Name, int product_ID, String product_Suppliername, int product_Cost) {
		super();
		this.product_Name = product_Name;
		this.product_ID = product_ID;
		
		this.product_Cost = product_Cost;
	}
	public Product() {
		super();
	}

}
