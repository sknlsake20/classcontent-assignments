package com.src.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.src.entity.Cracker;
import com.src.service.CrackerService;

@Controller
@RequestMapping("/cracker")
public class CrackerController {

    @Autowired
    private CrackerService crackerService;
    
    @GetMapping("/list")
    public String listCrackers(Model theModel) {
        List < Cracker > theCrackers = crackerService.getCrackers();
        
        theModel.addAttribute("crackers", theCrackers);
        return "list-crackers";
    }
    
    @GetMapping("/list1")
    public String listCrackers1(Model theModel) {
        List < Cracker > theCrackers = crackerService.getCrackers();
        
        theModel.addAttribute("crackers", theCrackers);
        return "list1-crackers";
    }

    @GetMapping("/showForm")
    public String showFormForAdd(Model theModel) {
    	Cracker theCracker = new Cracker();
        theModel.addAttribute("cracker", theCracker);
        return "cracker-form";
    }

   @PostMapping("/saveCracker")
    public String saveCracker(@ModelAttribute("cracker") Cracker theCracker) {
        crackerService.saveCracker(theCracker);
        return "redirect:/cracker/list";
    } 
    @GetMapping("/updateForm")
    public String showFormForUpdate(@RequestParam("crackerId") int theId,
        Model theModel) {
        Optional<Cracker> theCracker = crackerService.getCracker(theId);
        theModel.addAttribute("cracker", theCracker);
        return "cracker-form";
    } 

    @GetMapping("/delete")
    public String deleteCracker(@RequestParam("crackerId") int theId) {
    	Cracker c =new Cracker();
    	c.setId(theId);
        crackerService.deleteCracker(c);
        return "redirect:/cracker/list";
    }
    
	
    
}
